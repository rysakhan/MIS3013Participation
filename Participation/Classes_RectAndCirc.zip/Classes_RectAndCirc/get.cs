﻿namespace Classes_RectAndCirc
{
    public class get
    {
    }
}